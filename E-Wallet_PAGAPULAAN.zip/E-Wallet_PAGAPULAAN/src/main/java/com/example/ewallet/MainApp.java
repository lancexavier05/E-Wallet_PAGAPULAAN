package com.example.ewallet;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;

public class    MainApp extends Application {

    private static Stage primaryStage;
    public static User currentUser;


    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        primaryStage.setTitle("E-Wallet");
        switchScene("login-view.fxml");
        primaryStage.show();
    }


    public static void switchScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(MainApp.class.getResource(fxmlFile));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.centerOnScreen();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        AdminDAO adminDAO = new AdminDAO();
        String defaultPasswordHash = PasswordUtil.hash("admin123");

        if (adminDAO.login("admin", defaultPasswordHash) == null) {
            adminDAO.createAdmin("Super Admin", "admin", defaultPasswordHash);
        }

        launch(args);
    }



}
