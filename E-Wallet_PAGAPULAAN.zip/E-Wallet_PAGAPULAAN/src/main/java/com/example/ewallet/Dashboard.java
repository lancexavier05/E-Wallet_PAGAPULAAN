package com.example.ewallet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class Dashboard {

    @FXML private Label welcomeLabel;
    @FXML private Label balanceLabel;
    @FXML private Button logoutButton;

    private final WalletDAO walletDAO = new WalletDAO();

    @FXML
    private void initialize() {
        refreshDashboard();
    }

    private void refreshDashboard() {
        if (MainApp.currentUser == null) {
            MainApp.switchScene("login-view.fxml");
            return;
        }

        welcomeLabel.setText("Hi, " + MainApp.currentUser.getName());

        Wallet wallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
        if (wallet != null) {
            balanceLabel.setText("PHP " + wallet.getBalance().setScale(2, java.math.RoundingMode.HALF_UP));
        } else {
            balanceLabel.setText("PHP 0.00");
        }
    }

    @FXML
    private void handleCashIn() {
        MainApp.switchScene("cashin-view.fxml");
    }

    @FXML
    private void handleSendMoney() {
        MainApp.switchScene("send-money-view.fxml");
    }

    @FXML
    private void handlePayMerchant() {
        MainApp.switchScene("pay-merchant-view.fxml");
    }

    @FXML
    private void handleCashOut() {
        MainApp.switchScene("cashout-view.fxml");
    }

    @FXML
    private void handleViewHistory() {
        MainApp.switchScene("history-view.fxml");
    }

    @FXML
    private void handleAdminPanel() {
        MainApp.switchScene("admin-view.fxml");
    }

    @FXML
    private void handleLogout() {
        MainApp.currentUser = null;
        MainApp.switchScene("login-view.fxml");
    }
}