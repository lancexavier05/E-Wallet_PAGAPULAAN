package com.example.ewallet;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class UserDAO {

    public boolean register(String name, String phone, String pinHash) {
        String insertUser = "INSERT INTO users (name, phone, pin_hash) VALUES (?, ?, ?)";
        String insertWallet = "INSERT INTO wallets (user_id, balance, status) VALUES (?, ?, ?)";

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement userStmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS)) {
                userStmt.setString(1, name);
                userStmt.setString(2, phone);
                userStmt.setString(3, pinHash);
                userStmt.executeUpdate();

                ResultSet keys = userStmt.getGeneratedKeys();
                if (keys.next()) {
                    int newUserId = keys.getInt(1);

                    try (PreparedStatement walletStmt = conn.prepareStatement(insertWallet)) {
                        walletStmt.setInt(1, newUserId);
                        walletStmt.setBigDecimal(2, BigDecimal.ZERO);
                        walletStmt.setString(3, "ACTIVE");
                        walletStmt.executeUpdate();
                    }
                }
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public User login(String phone, String pinHash) {
        String sql = "SELECT * FROM users WHERE phone = ? AND pin_hash = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, phone);
            stmt.setString(2, pinHash);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                        rs.getInt("user_id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("pin_hash")
                );
            }
            return null;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }


    public boolean phoneExists(String phone) {
        String sql = "SELECT user_id FROM users WHERE phone = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, phone);
            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public User findByPhone(String phone) {
        String sql = "SELECT * FROM users WHERE phone = ?";

        try (java.sql.Connection conn = Database.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, phone);
            java.sql.ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                        rs.getInt("user_id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("pin_hash")
                );
            }
            return null;

        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<User> getAllUsers() {
        List<User> list = new java.util.ArrayList<>();
        String sql = "SELECT * FROM users";

        try (java.sql.Connection conn = Database.getConnection();
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new User(
                        rs.getInt("user_id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("pin_hash")
                ));
            }

        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}