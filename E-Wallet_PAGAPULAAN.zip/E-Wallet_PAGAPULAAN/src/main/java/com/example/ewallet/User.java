package com.example.ewallet;

public class User {

    private int userId;
    private String name;
    private String phone;
    private String pinHash;

    public User() {
    }

    public User(int userId, String name, String phone, String pinHash) {
        this.userId = userId;
        this.name = name;
        this.phone = phone;
        this.pinHash = pinHash;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPinHash() {
        return pinHash;
    }

    public void setPinHash(String pinHash) {
        this.pinHash = pinHash;
    }
}