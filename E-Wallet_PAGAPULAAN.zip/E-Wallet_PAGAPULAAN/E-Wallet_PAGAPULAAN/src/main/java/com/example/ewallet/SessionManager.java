package com.example.ewallet.session;

import java.io.*;

public class SessionManager {

    private static final String FILE_NAME = "session.dat";

    public static void saveSession(Session session) {
        try (ObjectOutputStream out =
                     new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {

            out.writeObject(session);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Session loadSession() {

        File file = new File(FILE_NAME);

        if (!file.exists())
            return null;

        try (ObjectInputStream in =
                     new ObjectInputStream(new FileInputStream(file))) {

            return (Session) in.readObject();

        } catch (IOException | ClassNotFoundException e) {
            return null;
        }
    }

    public static boolean hasSession() {
        return new File(FILE_NAME).exists();
    }

    public static void clearSession() {
        File file = new File(FILE_NAME);

        if (file.exists()) {
            file.delete();
        }
    }
}