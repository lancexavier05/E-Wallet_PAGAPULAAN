package com.example.ewallet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.math.BigDecimal;

public class CashIn {

    @FXML private ChoiceBox<String> methodChoiceBox;
    @FXML private TextField amountField;
    @FXML private Label errorLabel;
    @FXML private Button confirmButton;
    @FXML private Button backButton;

    private final WalletDAO walletDAO = new WalletDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    @FXML
    private void initialize() {
        methodChoiceBox.getItems().addAll("Bank Transfer", "Credit/Debit Card", "Over-the-Counter");
    }

    @FXML
    private void handleConfirm() {
        if (MainApp.currentUser == null) {
            MainApp.switchScene("login-view.fxml");
            return;
        }

        String amountText = amountField.getText().trim();
        String method = methodChoiceBox.getValue();

        if (method == null) {
            errorLabel.setText("Please select a payment method.");
            return;
        }

        if (amountText.isEmpty()) {
            errorLabel.setText("Please enter an amount.");
            return;
        }

        BigDecimal amount;
        try {
            amount = new BigDecimal(amountText);
        } catch (NumberFormatException e) {
            errorLabel.setText("Invalid amount.");
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            errorLabel.setText("Amount must be greater than zero.");
            return;
        }

        Wallet wallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
        if (wallet == null) {
            errorLabel.setText("Wallet not found.");
            return;
        }

        boolean credited = walletDAO.credit(wallet.getWalletId(), amount);

        if (credited) {
            transactionDAO.record(wallet.getWalletId(), null, "CASH_IN", amount, "SUCCESS");
            MainApp.switchScene("dashboard-view.fxml");
        } else {
            errorLabel.setText("Cash in failed. Please try again.");
        }
    }

    @FXML
    private void handleBack() {
        MainApp.switchScene("dashboard-view.fxml");
    }
}