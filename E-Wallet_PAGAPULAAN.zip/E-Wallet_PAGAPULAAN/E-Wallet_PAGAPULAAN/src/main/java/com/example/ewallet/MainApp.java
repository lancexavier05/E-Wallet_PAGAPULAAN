package com.example.ewallet;

import com.example.ewallet.session.Session;
import com.example.ewallet.session.SessionManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {

    private static Stage primaryStage;
    public static User currentUser;

    @Override
    public void start(Stage stage) throws IOException {

        primaryStage = stage;
        primaryStage.setTitle("E-Wallet");

        Session session = SessionManager.loadSession();

        if (session != null) {

            UserDAO userDAO = new UserDAO();

            currentUser = userDAO.getUserById(session.getUserId());

            if (currentUser != null) {
                switchScene("dashboard-view.fxml");
            } else {
                SessionManager.clearSession();
                switchScene("login-view.fxml");
            }

        } else {

            switchScene("login-view.fxml");

        }

        primaryStage.show();
    }

    public static void switchScene(String fxmlFile) {

        try {

            FXMLLoader loader =
                    new FXMLLoader(MainApp.class.getResource(fxmlFile));

            Parent root = loader.load();

            Scene scene = new Scene(root);

            primaryStage.setScene(scene);
            primaryStage.centerOnScreen();

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

    public static void logout() {

        SessionManager.clearSession();

        currentUser = null;

        switchScene("login-view.fxml");
    }

    public static void main(String[] args) {

        AdminDAO adminDAO = new AdminDAO();

        String defaultPasswordHash =
                PasswordUtil.hash("admin123");

        if (adminDAO.login("admin", defaultPasswordHash) == null) {

            adminDAO.createAdmin(
                    "Super Admin",
                    "admin",
                    defaultPasswordHash
            );

        }

        launch(args);

    }

}