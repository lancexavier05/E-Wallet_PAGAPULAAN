package com.example.ewallet;

import com.example.ewallet.session.Session;
import com.example.ewallet.session.SessionManager;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Login {

    @FXML
    private TextField phoneField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button loginButton;

    @FXML
    private Button goToRegisterButton;

    private final UserDAO userDAO = new UserDAO();

    @FXML
    private void handleLogin() {

        String phone = phoneField.getText().trim();
        String pin = passwordField.getText();

        if (phone.isEmpty() || pin.isEmpty()) {
            errorLabel.setText("Please enter phone and PIN.");
            return;
        }

        User user = userDAO.login(phone, PasswordUtil.hash(pin));

        if (user != null) {

            MainApp.currentUser = user;

            Session session = new Session(
                    user.getUserId(),
                    user.getPhone(),
                    user.getName()
            );

            SessionManager.saveSession(session);

            MainApp.switchScene("dashboard-view.fxml");

        } else {
            errorLabel.setText("Invalid phone number or PIN.");
        }
    }

    @FXML
    private void handleGoToRegister() {
        MainApp.switchScene("register-view.fxml");
    }
}