package com.example.ewallet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.math.BigDecimal;

public class SendMoney {

    @FXML private TextField recipientField;
    @FXML private TextField amountField;
    @FXML private PasswordField pinField;
    @FXML private Label errorLabel;
    @FXML private Label balanceHintLabel;
    @FXML private Button sendButton;
    @FXML private Button backButton;

    private final UserDAO userDAO = new UserDAO();
    private final WalletDAO walletDAO = new WalletDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    @FXML
    private void initialize() {
        if (MainApp.currentUser != null) {
            Wallet wallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
            if (wallet != null) {
                balanceHintLabel.setText("Available Balance: PHP " +
                        wallet.getBalance().setScale(2, java.math.RoundingMode.HALF_UP));
            }
        }
    }

    @FXML
    private void handleSend() {
        if (MainApp.currentUser == null) {
            MainApp.switchScene("login-view.fxml");
            return;
        }

        String recipientPhone = recipientField.getText().trim();
        String amountText = amountField.getText().trim();
        String pin = pinField.getText();

        if (recipientPhone.isEmpty() || amountText.isEmpty() || pin.isEmpty()) {
            errorLabel.setText("Please fill in all fields.");
            return;
        }


        if (!PasswordUtil.hash(pin).equals(MainApp.currentUser.getPinHash())) {
            errorLabel.setText("Incorrect PIN.");
            return;
        }

        User recipient = userDAO.findByPhone(recipientPhone);
        if (recipient == null) {
            errorLabel.setText("Recipient not found.");
            return;
        }

        if (recipient.getUserId() == MainApp.currentUser.getUserId()) {
            errorLabel.setText("You cannot send money to yourself.");
            return;
        }

        BigDecimal amount;
        try {
            amount = new BigDecimal(amountText);
        } catch (NumberFormatException e) {
            errorLabel.setText("Invalid amount.");
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            errorLabel.setText("Amount must be greater than zero.");
            return;
        }

        Wallet senderWallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
        Wallet recipientWallet = walletDAO.getWalletByUserId(recipient.getUserId());

        if (senderWallet == null || recipientWallet == null) {
            errorLabel.setText("Wallet error.");
            return;
        }


        if (senderWallet.getBalance().compareTo(amount) < 0) {
            errorLabel.setText("Insufficient balance.");
            return;
        }

        boolean debited = walletDAO.debit(senderWallet.getWalletId(), amount);
        if (!debited) {
            errorLabel.setText("Transaction failed. Please try again.");
            return;
        }

        walletDAO.credit(recipientWallet.getWalletId(), amount);

        transactionDAO.record(senderWallet.getWalletId(), null, "SEND_MONEY_OUT", amount, "SUCCESS");
        transactionDAO.record(recipientWallet.getWalletId(), null, "SEND_MONEY_IN", amount, "SUCCESS");

        MainApp.switchScene("dashboard-view.fxml");
    }

    @FXML
    private void handleBack() {
        MainApp.switchScene("dashboard-view.fxml");
    }
}