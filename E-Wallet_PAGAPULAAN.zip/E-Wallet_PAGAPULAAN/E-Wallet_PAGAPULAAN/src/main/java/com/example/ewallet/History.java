package com.example.ewallet;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class History {

    @FXML private TableView<Transaction> historyTable;
    @FXML private TableColumn<Transaction, Integer> txnIdColumn;
    @FXML private TableColumn<Transaction, String> typeColumn;
    @FXML private TableColumn<Transaction, java.math.BigDecimal> amountColumn;
    @FXML private TableColumn<Transaction, String> dateColumn;
    @FXML private TableColumn<Transaction, String> statusColumn;
    @FXML private Button backButton;

    private final WalletDAO walletDAO = new WalletDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    @FXML
    private void initialize() {
        txnIdColumn.setCellValueFactory(new PropertyValueFactory<>("txnId"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        dateColumn.setCellValueFactory(cellData -> {
            java.time.LocalDateTime ts = cellData.getValue().getTimestamp();
            String formatted = ts != null ? ts.toString() : "";
            return new javafx.beans.property.SimpleStringProperty(formatted);
        });

        loadHistory();
    }

    private void loadHistory() {
        if (MainApp.currentUser == null) {
            MainApp.switchScene("login-view.fxml");
            return;
        }

        Wallet wallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
        if (wallet == null) {
            return;
        }

        List<Transaction> transactions = transactionDAO.getHistoryByWalletId(wallet.getWalletId());
        ObservableList<Transaction> data = FXCollections.observableArrayList(transactions);
        historyTable.setItems(data);
    }

    @FXML
    private void handleBack() {
        MainApp.switchScene("dashboard-view.fxml");
    }
}