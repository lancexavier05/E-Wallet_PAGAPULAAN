package com.example.ewallet;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public boolean record(int walletId, Integer methodId, String type, BigDecimal amount, String status) {
        String sql = "INSERT INTO transactions (wallet_id, method_id, type, amount, status) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, walletId);
            if (methodId != null) {
                stmt.setInt(2, methodId);
            } else {
                stmt.setNull(2, java.sql.Types.INTEGER);
            }
            stmt.setString(3, type);
            stmt.setBigDecimal(4, amount);
            stmt.setString(5, status);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Transaction> getHistoryByWalletId(int walletId) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE wallet_id = ? ORDER BY timestamp DESC";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, walletId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Integer methodId = rs.getObject("method_id") != null ? rs.getInt("method_id") : null;
                Timestamp ts = rs.getTimestamp("timestamp");

                list.add(new Transaction(
                        rs.getInt("txn_id"),
                        rs.getInt("wallet_id"),
                        methodId,
                        rs.getString("type"),
                        rs.getBigDecimal("amount"),
                        ts != null ? ts.toLocalDateTime() : null,
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions ORDER BY timestamp DESC";

        try (Connection conn = Database.getConnection();
             java.sql.Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Integer methodId = rs.getObject("method_id") != null ? rs.getInt("method_id") : null;
                Timestamp ts = rs.getTimestamp("timestamp");

                list.add(new Transaction(
                        rs.getInt("txn_id"),
                        rs.getInt("wallet_id"),
                        methodId,
                        rs.getString("type"),
                        rs.getBigDecimal("amount"),
                        ts != null ? ts.toLocalDateTime() : null,
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}