package com.example.ewallet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Register {

    @FXML private TextField nameField;
    @FXML private TextField phoneField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label errorLabel;
    @FXML private Button registerButton;
    @FXML private Button backToLoginButton;

    private final UserDAO userDAO = new UserDAO();

    @FXML
    private void handleRegister() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String pin = passwordField.getText();
        String confirmPin = confirmPasswordField.getText();

        if (name.isEmpty() || phone.isEmpty() || pin.isEmpty()) {
            errorLabel.setText("Please fill in all fields.");
            return;
        }

        if (!pin.equals(confirmPin)) {
            errorLabel.setText("PINs do not match.");
            return;
        }

        if (userDAO.phoneExists(phone)) {
            errorLabel.setText("Phone number already registered.");
            return;
        }

        boolean success = userDAO.register(name, phone, PasswordUtil.hash(pin));

        if (success) {
            MainApp.switchScene("login-view.fxml");
        } else {
            errorLabel.setText("Registration failed. Please try again.");
        }
    }

    @FXML
    private void handleBackToLogin() {
        MainApp.switchScene("login-view.fxml");
    }
}