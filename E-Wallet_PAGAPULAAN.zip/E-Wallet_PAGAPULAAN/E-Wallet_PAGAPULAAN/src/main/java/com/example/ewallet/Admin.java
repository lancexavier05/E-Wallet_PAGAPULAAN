package com.example.ewallet;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.Optional;

public class Admin {

    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, Integer> userIdColumn;
    @FXML private TableColumn<User, String> userNameColumn;
    @FXML private TableColumn<User, String> userPhoneColumn;
    @FXML private TableColumn<User, String> userStatusColumn;
    @FXML private Button suspendUserButton;

    @FXML private TableView<Transaction> allTxnsTable;
    @FXML private TableColumn<Transaction, Integer> txnIdColumn2;
    @FXML private TableColumn<Transaction, Integer> fromColumn;
    @FXML private TableColumn<Transaction, Integer> toColumn;
    @FXML private TableColumn<Transaction, java.math.BigDecimal> amountColumn2;
    @FXML private TableColumn<Transaction, String> statusColumn2;

    @FXML private Button backButton;

    private final UserDAO userDAO = new UserDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();
    private final AdminDAO adminDAO = new AdminDAO();

    @FXML
    private void initialize() {
        if (!promptAdminLogin()) {
            MainApp.switchScene("dashboard-view.fxml");
            return;
        }

        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        userNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        userPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        userStatusColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty("ACTIVE"));

        usersTable.setItems(FXCollections.observableArrayList(userDAO.getAllUsers()));

        txnIdColumn2.setCellValueFactory(new PropertyValueFactory<>("txnId"));
        fromColumn.setCellValueFactory(new PropertyValueFactory<>("walletId"));
        toColumn.setCellValueFactory(new PropertyValueFactory<>("walletId"));
        amountColumn2.setCellValueFactory(new PropertyValueFactory<>("amount"));
        statusColumn2.setCellValueFactory(new PropertyValueFactory<>("status"));

        allTxnsTable.setItems(FXCollections.observableArrayList(transactionDAO.getAllTransactions()));
    }

    // Simple dialog-based admin login gate
    private boolean promptAdminLogin() {
        Dialog<javafx.util.Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Admin Login");
        dialog.setHeaderText("Enter admin credentials");

        ButtonType loginButtonType = new ButtonType("Login", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        javafx.scene.layout.VBox content = new javafx.scene.layout.VBox(10, usernameField, passwordField);
        content.setStyle("-fx-padding: 20;");
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(buttonType -> {
            if (buttonType == loginButtonType) {
                return new javafx.util.Pair<>(usernameField.getText(), passwordField.getText());
            }
            return null;
        });

        Optional<javafx.util.Pair<String, String>> result = dialog.showAndWait();

        if (result.isPresent()) {
            String username = result.get().getKey();
            String password = result.get().getValue();
            AdminAccount admin = adminDAO.login(username, PasswordUtil.hash(password));
            if (admin != null) {
                return true;
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid admin credentials.");
                alert.showAndWait();
                return false;
            }
        }
        return false;
    }

    @FXML
    private void handleSuspendUser() {
        
    }

    @FXML
    private void handleBack() {
        MainApp.switchScene("dashboard-view.fxml");
    }

    public void handleConfirm(ActionEvent actionEvent) {
    }
}