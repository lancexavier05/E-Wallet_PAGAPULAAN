package com.example.ewallet;

public class AdminAccount {

    private int adminId;
    private String name;
    private String username;
    private String passwordHash;

    public AdminAccount() {
    }

    public AdminAccount(int adminId, String name, String username, String passwordHash) {
        this.adminId = adminId;
        this.name = name;
        this.username = username;
        this.passwordHash = passwordHash;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
}