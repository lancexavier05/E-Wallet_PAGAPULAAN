package com.example.ewallet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.math.BigDecimal;

public class PayMerchant {

    @FXML private TextField merchantField;
    @FXML private TextField amountField;
    @FXML private PasswordField pinField;
    @FXML private Label errorLabel;
    @FXML private Button payButton;
    @FXML private Button backButton;

    private final WalletDAO walletDAO = new WalletDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    @FXML
    private void handlePay() {
        if (MainApp.currentUser == null) {
            MainApp.switchScene("login-view.fxml");
            return;
        }

        String merchantCode = merchantField.getText().trim();
        String amountText = amountField.getText().trim();
        String pin = pinField.getText();

        if (merchantCode.isEmpty() || amountText.isEmpty() || pin.isEmpty()) {
            errorLabel.setText("Please fill in all fields.");
            return;
        }

        if (!PasswordUtil.hash(pin).equals(MainApp.currentUser.getPinHash())) {
            errorLabel.setText("Incorrect PIN.");
            return;
        }

        BigDecimal amount;
        try {
            amount = new BigDecimal(amountText);
        } catch (NumberFormatException e) {
            errorLabel.setText("Invalid amount.");
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            errorLabel.setText("Amount must be greater than zero.");
            return;
        }

        Wallet wallet = walletDAO.getWalletByUserId(MainApp.currentUser.getUserId());
        if (wallet == null) {
            errorLabel.setText("Wallet not found.");
            return;
        }

        if (wallet.getBalance().compareTo(amount) < 0) {
            errorLabel.setText("Insufficient balance.");
            return;
        }

        boolean debited = walletDAO.debit(wallet.getWalletId(), amount);

        if (debited) {
            transactionDAO.record(wallet.getWalletId(), null, "PAY_MERCHANT", amount, "SUCCESS");
            MainApp.switchScene("dashboard-view.fxml");
        } else {
            errorLabel.setText("Payment failed. Please try again.");
        }
    }

    @FXML
    private void handleBack() {
        MainApp.switchScene("dashboard-view.fxml");
    }
}