package com.example.ewallet;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Transaction {

    private int txnId;
    private int walletId;
    private Integer methodId;
    private String type;
    private BigDecimal amount;
    private LocalDateTime timestamp;
    private String status;

    public Transaction() {
    }

    public Transaction(int txnId, int walletId, Integer methodId, String type,
                       BigDecimal amount, LocalDateTime timestamp, String status) {
        this.txnId = txnId;
        this.walletId = walletId;
        this.methodId = methodId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.status = status;
    }

    public int getTxnId() {
        return txnId;
    }

    public void setTxnId(int txnId) {
        this.txnId = txnId;
    }

    public int getWalletId() {
        return walletId;
    }

    public void setWalletId(int walletId) {
        this.walletId = walletId;
    }

    public Integer getMethodId() {
        return methodId;
    }

    public void setMethodId(Integer methodId) {
        this.methodId = methodId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}