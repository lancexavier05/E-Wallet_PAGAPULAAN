package com.example.ewallet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {

    public boolean createAdmin(String name, String username, String passwordHash) {
        String sql = "INSERT INTO admins (name, username, password_hash) VALUES (?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, username);
            stmt.setString(3, passwordHash);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public AdminAccount login(String username, String passwordHash) {
        String sql = "SELECT * FROM admins WHERE username = ? AND password_hash = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, passwordHash);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new AdminAccount(
                        rs.getInt("admin_id"),
                        rs.getString("name"),
                        rs.getString("username"),
                        rs.getString("password_hash")
                );
            }
            return null;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}