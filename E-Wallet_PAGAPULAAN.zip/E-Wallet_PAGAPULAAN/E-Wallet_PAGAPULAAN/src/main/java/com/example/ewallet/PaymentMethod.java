package com.example.ewallet;

public class PaymentMethod {

    private int methodId;
    private int userId;
    private String type;

    public PaymentMethod() {
    }

    public PaymentMethod(int methodId, int userId, String type) {
        this.methodId = methodId;
        this.userId = userId;
        this.type = type;
    }

    public int getMethodId() {
        return methodId;
    }

    public void setMethodId(int methodId) {
        this.methodId = methodId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}