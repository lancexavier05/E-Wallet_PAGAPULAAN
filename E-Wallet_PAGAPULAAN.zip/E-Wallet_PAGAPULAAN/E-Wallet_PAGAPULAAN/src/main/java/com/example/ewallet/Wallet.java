package com.example.ewallet;

import java.math.BigDecimal;

public class Wallet {

    private int walletId;
    private int userId;
    private BigDecimal balance;
    private String status;

    public Wallet() {
    }

    public Wallet(int walletId, int userId, BigDecimal balance, String status) {
        this.walletId = walletId;
        this.userId = userId;
        this.balance = balance;
        this.status = status;
    }

    public int getWalletId() {
        return walletId;
    }

    public void setWalletId(int walletId) {
        this.walletId = walletId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}