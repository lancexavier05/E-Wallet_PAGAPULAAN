module com.example.ewallet {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.ewallet to javafx.fxml;
    exports com.example.ewallet;
}